/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Funciones.h
 * Author: cueva.r
 *
 * Created on 31 de agosto de 2022, 10:27 AM
 */

#ifndef FUNCIONES_H
#define FUNCIONES_H
    void generaalumno();
    void muestralumnosbin();
    void creaconsolidado();
    void generaconsolidado();
    void actualizaconsolidado();
    void imprimeconsolidado();
    
#endif /* FUNCIONES_H */
