/* 
 * File:   main.cpp
 * Author: cueva.r
 *
 * Created on 31 de agosto de 2022, 10:25 AM
 */
#include "Funciones.h"

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    
    generaalumno();
    generaconsolidado();
    imprimeconsolidado();
    return 0;
}

