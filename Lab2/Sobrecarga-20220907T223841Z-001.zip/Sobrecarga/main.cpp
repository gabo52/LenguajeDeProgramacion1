/* 
 * File:   main.cpp
 * Author: cueva.r
 *
 * Created on 7 de septiembre de 2022, 10:56 AM
 */
#include <iostream>
#include <fstream>
#include <cstdlib>
#include "Estructura.h"
#include "Funciones.h"
#include <cstring>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    talumno talu1,talu2;
    talumno arralu1[10];
    
    talu1.codigo=20112910;
    strcpy(talu1.nombre,"Perez-Albela");
    talu1.promedio=12.5;

    talu2.codigo=20132210;
    strcpy(talu2.nombre,"Perez-Aliaga");
    talu2.promedio=13.0;
    
    
    cout << talu1 + talu2;
    talu1 * talu2;
    
    cout << talu2 << talu1 ;
    
    arralu1[0].codigo=20112910;
    strcpy(arralu1[0].nombre,"Perez-Albela");
    arralu1[0].promedio=12.5;

    arralu1[1].codigo=20132210;
    strcpy(arralu1[1].nombre,"Perez-Aliaga");
    arralu1[1].promedio=13.0;
    
    arralu1[2].codigo=20181510;
    strcpy(arralu1[2].nombre,"Cossio-Montoya");
    arralu1[2].promedio=17.0;
    
    arralu1[3].codigo=0;
    
    cout << arralu1;
    
    ofstream arch("Reporte.txt",ios::out);
    if(!arch){
        cout << "No se puede abrir Reporte.txt";
        exit(1);
    }
    arch << arralu1;
    
    return 0;
}

