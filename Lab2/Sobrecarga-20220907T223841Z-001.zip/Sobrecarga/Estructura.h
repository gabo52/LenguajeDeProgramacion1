/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Estructura.h
 * Author: cueva.r
 *
 * Created on 7 de septiembre de 2022, 10:57 AM
 */

#ifndef ESTRUCTURA_H
#define ESTRUCTURA_H

typedef struct{
    int codigo;
    char nombre[100];
    double promedio;
}talumno;


#endif /* ESTRUCTURA_H */
