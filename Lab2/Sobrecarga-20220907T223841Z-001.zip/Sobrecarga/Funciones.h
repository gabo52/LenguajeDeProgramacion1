/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Funciones.h
 * Author: cueva.r
 *
 * Created on 7 de septiembre de 2022, 10:57 AM
 */
#include <iostream>
#include <fstream>
#include "Estructura.h"

using namespace std;

#ifndef FUNCIONES_H
#define FUNCIONES_H

    double operator + (talumno ,talumno );
    void operator * (talumno ,talumno );
    ostream& operator << (ostream &out,talumno );
    ostream&  operator << (ostream &out,talumno *);
    ofstream&  operator << (ofstream &arch,talumno *);

#endif /* FUNCIONES_H */
