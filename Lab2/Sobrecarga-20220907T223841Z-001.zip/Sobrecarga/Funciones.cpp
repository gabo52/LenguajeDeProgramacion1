
/* 
 * File:   Funciones.cpp
 * Author: cueva.r
 * 
 * Created on 7 de septiembre de 2022, 10:57 AM
 */
#include <iostream>
#include <iomanip>
#include "Funciones.h"
#include "Estructura.h"

using namespace std;


double operator + (talumno t1,talumno t2){
    
    return (t1.promedio+t2.promedio)/2;
    
}

void operator * (talumno t1,talumno t2){
    cout<< endl<<(t1.promedio+t2.promedio)/2;
}

ostream&  operator << (ostream &out,talumno t1){
    out << endl;
    out <<"Codigo:"<< t1.codigo << endl;
    out <<"Nombre:"<< t1.nombre << endl;
    out <<"Promedio:"<< setprecision(2)<<fixed<< t1.promedio << endl;
    return out;
} 

ostream&  operator << (ostream &out,talumno *t1){
    out <<endl<< "Los alumnos son:"<<endl;
    for(int i=0;t1[i].codigo;i++)
    {
        out << endl;
        out <<"Codigo:"<< t1[i].codigo << endl;
        out <<"Nombre:"<< t1[i].nombre << endl;
        out <<"Promedio:"<< setprecision(2)<<fixed<< t1[i].promedio << endl;    
        
    }
    return out;
} 

ofstream&  operator << (ofstream &arch,talumno *t1){
    arch <<endl<< "Los alumnos son:"<<endl;
    for(int i=0;t1[i].codigo;i++)
    {
        arch << endl;
        arch <<"Codigo:"<< t1[i].codigo << endl;
        arch <<"Nombre:"<< t1[i].nombre << endl;
        arch <<"Promedio:"<< setprecision(2)<<fixed<< t1[i].promedio << endl;    
    }
    return arch;
} 